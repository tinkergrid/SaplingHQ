import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Star, 
  BookOpen, 
  Smile, 
  Plus, 
  ChevronRight, 
  Award, 
  LayoutDashboard, 
  Gamepad2,
  Settings,
  User as UserIcon,
  Calendar as CalendarIcon,
  CheckCircle2,
  TreeDeciduous,
  Wind,
  Trees,
  CloudRain,
  Sprout,
  Warehouse,
  MessageSquare,
  Users,
  ChevronDown,
  Mail,
  Sun,
  Volume2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { cn } from './lib/utils';
import { 
  Child, 
  BehaviorLog, 
  Activity, 
  BehaviorType, 
  SchoolEvent, 
  School, 
  SchoolClass, 
  Teacher, 
  Message 
} from './types';

// Mock Data
const MOCK_TEACHERS: Teacher[] = [
  { id: 't1', name: 'Mrs. Willow', role: 'Lead Teacher', avatar: '👩‍🏫', email: 'willow@sapling.edu' },
  { id: 't2', name: 'Mr. Birch', role: 'Assistant Teacher', avatar: '👨‍🏫', email: 'birch@sapling.edu' }
];

const MOCK_STUDENTS: Child[] = [
  {
    id: '1',
    name: 'Leo',
    avatar: '🦁',
    attendanceStatus: 'present',
    checkInTime: '07:45 AM',
    behaviorLogs: [
      { id: '1', type: 'kindness', timestamp: Date.now() - 86400000, note: 'Shared his blocks with Maya' },
    ],
    milestones: [
      { id: 'm1', category: 'cognitive', title: 'Identifies primary colors', completed: true },
      { id: 'm2', category: 'social', title: 'Plays cooperatively', completed: false },
    ]
  },
  {
    id: '2',
    name: 'Maya',
    avatar: '🦋',
    attendanceStatus: 'present',
    checkInTime: '08:05 AM',
    behaviorLogs: [],
    milestones: [
      { id: 'm4', category: 'language', title: 'Uses 4-5 word sentences', completed: true },
    ]
  }
];

const MOCK_CLASSES: SchoolClass[] = [
  { id: 'c1', name: 'Grade R (The Seedlings)', teachers: [MOCK_TEACHERS[0]], students: MOCK_STUDENTS },
  { id: 'c2', name: 'Grade 1 (The Sprouts)', teachers: [MOCK_TEACHERS[1]], students: [] }
];

const MOCK_SCHOOL: School = {
  id: 's1',
  name: 'Oakwood Early Learning',
  description: 'Nurturing curiosity and kindness since 2010.',
  announcements: [
    'Spring Picnic this Friday! Don\'t forget your sunhats.',
    'New pattern games added to the Play section.'
  ],
  classes: MOCK_CLASSES
};

const MOCK_EVENTS: SchoolEvent[] = [
  { id: 'e1', title: 'Field Trip - Friday', date: '2026-03-27', time: '09:00 AM', type: 'social' },
  { id: 'e2', title: 'Math Quiz - tomorrow', date: '2026-03-26', time: '10:30 AM', type: 'academic' },
  { id: 'e3', title: 'Parent Coffee', date: '2026-03-28', time: '02:00 PM', type: 'social' }
];

const MOCK_MESSAGES: Message[] = [
  { id: 'msg1', senderId: 't1', senderName: 'Mrs. Willow', content: 'Leo had a great day sharing today!', timestamp: Date.now() - 3600000 },
];

// Components
const Card = ({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("bg-white rounded-[32px] p-6 shadow-sm border border-sapling-accent/20", className)} {...props}>
    {children}
  </div>
);

const Button = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className 
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  className?: string;
}) => {
  const variants = {
    primary: "bg-sapling-green text-white hover:bg-sapling-green/90",
    secondary: "bg-white text-sapling-green border border-sapling-green hover:bg-sapling-cream",
    outline: "bg-transparent text-sapling-green border border-sapling-accent hover:bg-sapling-accent/10",
    ghost: "bg-transparent text-sapling-green hover:bg-sapling-accent/10"
  };
  
  return (
    <button 
      onClick={onClick}
      className={cn(
        "px-6 py-3 rounded-full font-medium transition-all active:scale-95 flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
    >
      {children}
    </button>
  );
};

// Views
const DashboardView = ({ userRole, onOpenTracker }: { userRole: 'parent' | 'teacher'; onOpenTracker: () => void }) => {
  return (
    <div className="space-y-6">
      {/* Daily Sapling Widget */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-white to-sapling-cream/30" onClick={onOpenTracker}>
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-serif">Daily Sapling</h3>
            <p className="text-xs opacity-60">School Growth snapshot</p>
          </div>
          <Award className="w-6 h-6 text-sapling-green/40" />
        </div>
        <div className="flex justify-center py-4">
          <div className="relative">
            <TreeDeciduous className="w-24 h-24 text-sapling-green/20" />
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <div className="w-16 h-16 rounded-full bg-sapling-green/10 border-4 border-sapling-green/20 flex items-center justify-center">
                <span className="text-2xl font-bold text-sapling-green">84%</span>
              </div>
            </motion.div>
          </div>
        </div>
        <p className="text-center text-sm font-medium text-sapling-green">Tapping opens full tracker</p>
      </Card>

      {/* Attendance Dewdrop */}
      <div className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-sapling-accent/20 shadow-sm">
        <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
          <CloudRain className="w-5 h-5 text-blue-400" />
        </div>
        <div className="flex-1">
          <p className="text-xs uppercase tracking-widest font-bold opacity-40">Attendance Dewdrop</p>
          <p className="font-medium">
            {userRole === 'teacher' ? "22/25 Saplings present today." : "Leo is checked in at 07:45 AM."}
          </p>
        </div>
        <ChevronRight className="w-5 h-5 opacity-20" />
      </div>

      {/* Upcoming Harvest */}
      <div className="space-y-3">
        <h3 className="text-sm uppercase tracking-widest font-bold opacity-40 px-2">Upcoming Harvest</h3>
        <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
          {MOCK_EVENTS.map(event => (
            <div key={event.id} className="min-w-[200px] p-4 bg-white rounded-2xl border border-sapling-accent/20 shadow-sm">
              <p className="text-[10px] uppercase tracking-wider font-bold text-sapling-green/60 mb-1">{event.date}</p>
              <p className="font-medium truncate">{event.title}</p>
              <p className="text-xs opacity-50">{event.time}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const DirectoryView = () => {
  const [expandedLevel, setExpandedLevel] = useState<string | null>('school');
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [selectedTeacher, setSelectedTeacher] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <h2 className="text-3xl">The Forest Map</h2>
      
      {/* Level 1: The School */}
      <Card className={cn("transition-all", expandedLevel === 'school' ? "ring-2 ring-sapling-green/20" : "")}>
        <div 
          className="flex items-center gap-4 cursor-pointer"
          onClick={() => setExpandedLevel(expandedLevel === 'school' ? null : 'school')}
        >
          <div className="w-12 h-12 rounded-2xl bg-sapling-green/10 flex items-center justify-center">
            <TreeDeciduous className="w-6 h-6 text-sapling-green" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl">The Great Oak</h3>
            <p className="text-xs opacity-60">{MOCK_SCHOOL.name}</p>
          </div>
          <ChevronDown className={cn("w-5 h-5 transition-transform", expandedLevel === 'school' ? "rotate-180" : "")} />
        </div>
        
        <AnimatePresence>
          {expandedLevel === 'school' && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="pt-6 space-y-4">
                <div className="p-4 bg-sapling-cream rounded-2xl text-sm">
                  <p className="font-bold mb-1">Announcements</p>
                  <ul className="list-disc list-inside opacity-70 space-y-1">
                    {MOCK_SCHOOL.announcements.map((a, i) => <li key={i}>{a}</li>)}
                  </ul>
                </div>
                
                <div className="space-y-2">
                  <p className="text-[10px] uppercase tracking-widest font-bold opacity-40">The Branches (Classes)</p>
                  {MOCK_SCHOOL.classes.map(cls => (
                    <button 
                      key={cls.id}
                      onClick={() => {
                        setSelectedClass(cls.id);
                        setExpandedLevel('class');
                      }}
                      className="w-full flex items-center justify-between p-4 bg-white border border-sapling-accent/20 rounded-2xl hover:bg-sapling-cream transition-colors"
                    >
                      <span className="font-medium">{cls.name}</span>
                      <ChevronRight className="w-4 h-4 opacity-30" />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      {/* Level 2 & 3: Classes and Teachers */}
      {selectedClass && expandedLevel === 'class' && (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <div className="flex items-center gap-2 mb-4">
            <button onClick={() => setExpandedLevel('school')} className="text-sapling-green opacity-40"><ChevronRight className="w-5 h-5 rotate-180" /></button>
            <h3 className="text-xl">The Gardeners</h3>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {MOCK_SCHOOL.classes.find(c => c.id === selectedClass)?.teachers.map(teacher => (
              <Card key={teacher.id} className="flex items-center gap-4 p-4">
                <div className="text-3xl">{teacher.avatar}</div>
                <div className="flex-1">
                  <p className="font-bold">{teacher.name}</p>
                  <p className="text-xs opacity-60">{teacher.role}</p>
                </div>
                <button 
                  onClick={() => {
                    setSelectedTeacher(teacher.id);
                    setExpandedLevel('students');
                  }}
                  className="p-2 bg-sapling-green/10 rounded-full text-sapling-green"
                >
                  <Users className="w-5 h-5" />
                </button>
              </Card>
            ))}
          </div>
        </motion.div>
      )}

      {/* Level 4: Students */}
      {selectedTeacher && expandedLevel === 'students' && (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <div className="flex items-center gap-2 mb-4">
            <button onClick={() => setExpandedLevel('class')} className="text-sapling-green opacity-40"><ChevronRight className="w-5 h-5 rotate-180" /></button>
            <h3 className="text-xl">The Saplings</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {MOCK_STUDENTS.map(student => (
              <div key={student.id} className="text-center space-y-2">
                <div className="w-16 h-16 mx-auto bg-white rounded-full border-2 border-sapling-accent/20 flex items-center justify-center text-3xl shadow-sm">
                  {student.avatar}
                </div>
                <p className="text-xs font-bold">{student.name}</p>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

// Pattern Game Component
const PatternGame = () => {
  const shapes = ['🔴', '🔵', '🟡', '🟢', '⭐', '💎'];
  const [pattern, setPattern] = useState<string[]>([]);
  const [options, setOptions] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState('What comes next?');
  const [correctAnswer, setCorrectAnswer] = useState('');

  const startNewRound = () => {
    const pType = Math.floor(Math.random() * 3);
    const s1 = shapes[Math.floor(Math.random() * shapes.length)];
    let s2 = shapes[Math.floor(Math.random() * shapes.length)];
    while (s2 === s1) s2 = shapes[Math.floor(Math.random() * shapes.length)];
    let s3 = shapes[Math.floor(Math.random() * shapes.length)];
    while (s3 === s1 || s3 === s2) s3 = shapes[Math.floor(Math.random() * shapes.length)];

    let newPattern: string[] = [];
    let next: string = '';

    if (pType === 0) { // ABAB
      newPattern = [s1, s2, s1, s2, s1];
      next = s2;
    } else if (pType === 1) { // AABAAB
      newPattern = [s1, s1, s2, s1, s1];
      next = s2;
    } else { // ABCABC
      newPattern = [s1, s2, s3, s1, s2];
      next = s3;
    }

    setPattern(newPattern);
    setCorrectAnswer(next);
    const opts = [next, ...shapes.filter(s => s !== next).sort(() => 0.5 - Math.random()).slice(0, 2)];
    setOptions(opts.sort(() => 0.5 - Math.random()));
    setMessage('What comes next?');
  };

  useEffect(() => {
    startNewRound();
  }, []);

  const checkAnswer = (ans: string) => {
    if (ans === correctAnswer) {
      setScore(s => s + 1);
      setMessage('Great job! 🎉');
      setTimeout(startNewRound, 1500);
    } else {
      setMessage('Try again! ❤️');
    }
  };

  return (
    <Card className="text-center bg-white/80 backdrop-blur-sm border-4 border-sapling-green/20">
      <h3 className="text-xl mb-4 font-bold">Pattern Fun</h3>
      <div className="flex justify-center gap-2 mb-6 text-3xl">
        {pattern.map((s, i) => (
          <motion.div key={i} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: i * 0.1 }}>
            {s}
          </motion.div>
        ))}
        <div className="w-10 h-10 border-2 border-dashed border-sapling-accent rounded-lg flex items-center justify-center text-xl">?</div>
      </div>
      <p className="mb-4 font-medium">{message}</p>
      <div className="flex justify-center gap-3">
        {options.map((opt, i) => (
          <button
            key={i}
            onClick={() => checkAnswer(opt)}
            className="text-3xl p-3 bg-sapling-cream rounded-xl hover:bg-sapling-accent/30 transition-colors active:scale-90"
          >
            {opt}
          </button>
        ))}
      </div>
      <div className="mt-4 text-xs font-bold text-sapling-green/60 uppercase tracking-widest">
        Stars: {score} ⭐
      </div>
    </Card>
  );
};

const HubView = ({ role }: { role: 'parent' | 'teacher' | 'child' }) => {
  if (role === 'parent') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-sapling-green/10 flex items-center justify-center text-3xl">🏡</div>
          <div>
            <h2 className="text-3xl">My Garden</h2>
            <p className="opacity-60">Manage your family ecosystem</p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4">
          <Card className="flex items-center gap-4">
            <UserIcon className="w-6 h-6 text-sapling-green" />
            <div className="flex-1">
              <p className="font-bold">Leo's Data</p>
              <p className="text-xs opacity-60">Growth history & records</p>
            </div>
            <ChevronRight className="w-5 h-5 opacity-20" />
          </Card>
          <Card className="flex items-center gap-4">
            <Mail className="w-6 h-6 text-sapling-green" />
            <div className="flex-1">
              <p className="font-bold">Contact Details</p>
              <p className="text-xs opacity-60">Update emergency info</p>
            </div>
            <ChevronRight className="w-5 h-5 opacity-20" />
          </Card>
        </div>
      </div>
    );
  }

  if (role === 'teacher') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-sapling-green/10 flex items-center justify-center text-3xl">🌱</div>
          <div>
            <h2 className="text-3xl">The Greenhouse</h2>
            <p className="opacity-60">Teacher workspace</p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4">
          <Card className="bg-sapling-green text-white">
            <div className="flex items-center gap-4">
              <Sun className="w-8 h-8" />
              <div>
                <h3 className="text-xl">Send a Sunbeam</h3>
                <p className="text-sm opacity-80">Positive alert to the whole class</p>
              </div>
            </div>
          </Card>
          <Card className="flex items-center gap-4">
            <BookOpen className="w-6 h-6 text-sapling-green" />
            <div className="flex-1">
              <p className="font-bold">Lesson Planning</p>
              <p className="text-xs opacity-60">Organize weekly activities</p>
            </div>
            <ChevronRight className="w-5 h-5 opacity-20" />
          </Card>
          <Card className="flex items-center gap-4">
            <Users className="w-6 h-6 text-sapling-green" />
            <div className="flex-1">
              <p className="font-bold">Mass Attendance</p>
              <p className="text-xs opacity-60">Update all saplings at once</p>
            </div>
            <ChevronRight className="w-5 h-5 opacity-20" />
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 text-center py-6">
      <h2 className="text-4xl">My Little Patch</h2>
      <div className="relative w-40 h-40 mx-auto">
        <TreeDeciduous className="w-full h-full text-sapling-green" />
        <motion.div 
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute top-1/4 left-1/2 -translate-x-1/2 text-5xl"
        >
          🍎
        </motion.div>
      </div>
      
      <PatternGame />

      <div className="grid grid-cols-1 gap-4">
        <button className="p-6 bg-white rounded-[32px] border-4 border-sapling-green flex items-center justify-center gap-4 text-2xl font-bold shadow-lg">
          <Volume2 className="w-8 h-8" />
          Growth Story
        </button>
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'calendar' | 'directory' | 'communications' | 'hubs'>('home');
  const [userRole, setUserRole] = useState<'parent' | 'teacher' | 'child'>('parent');
  const [showTracker, setShowTracker] = useState(false);

  return (
    <div className="min-h-screen pb-24 max-w-md mx-auto bg-sapling-cream relative shadow-2xl overflow-hidden">
      {/* Header */}
      <header className="p-6 pt-12 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-serif leading-tight">Sapling HQ</h1>
          <p className="text-sm opacity-60 italic">Nurturing growth in the Soil.</p>
        </div>
        <button 
          onClick={() => setActiveTab('hubs')}
          className="w-12 h-12 rounded-full bg-white shadow-sm border border-sapling-accent/20 flex items-center justify-center text-xl"
        >
          {userRole === 'parent' ? '🏡' : userRole === 'teacher' ? '🌱' : '🍎'}
        </button>
      </header>

      {/* Role Switcher (For Demo) */}
      <div className="px-6 mb-4 flex gap-2 overflow-x-auto no-scrollbar">
        <button onClick={() => setUserRole('parent')} className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase", userRole === 'parent' ? "bg-sapling-green text-white" : "bg-white opacity-40")}>Parent View</button>
        <button onClick={() => setUserRole('teacher')} className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase", userRole === 'teacher' ? "bg-sapling-green text-white" : "bg-white opacity-40")}>Teacher View</button>
        <button onClick={() => setUserRole('child')} className={cn("px-3 py-1 rounded-full text-[10px] font-bold uppercase", userRole === 'child' ? "bg-sapling-green text-white" : "bg-white opacity-40")}>Child View</button>
      </div>

      <main className="px-6 space-y-6">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div key="home" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <DashboardView userRole={userRole === 'child' ? 'parent' : userRole as any} onOpenTracker={() => setShowTracker(true)} />
            </motion.div>
          )}

          {activeTab === 'calendar' && (
            <motion.div key="calendar" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <h2 className="text-3xl mb-6">Seasons</h2>
              <Card className="h-64 flex items-center justify-center text-sapling-green/40 italic">
                Full Calendar View
              </Card>
            </motion.div>
          )}

          {activeTab === 'directory' && (
            <motion.div key="directory" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <DirectoryView />
            </motion.div>
          )}

          {activeTab === 'communications' && (
            <motion.div key="communications" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <h2 className="text-3xl mb-6">The Breeze</h2>
              <div className="space-y-4">
                {MOCK_MESSAGES.map(msg => (
                  <Card key={msg.id} className="bg-white/60">
                    <p className="text-xs font-bold text-sapling-green mb-1">{msg.senderName}</p>
                    <p className="text-sm">{msg.content}</p>
                    <p className="text-[10px] opacity-40 mt-2">{format(msg.timestamp, 'h:mm a')}</p>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'hubs' && (
            <motion.div key="hubs" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
              <HubView role={userRole} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Behavior Tracker Modal (Simplified for demo) */}
      <AnimatePresence>
        {showTracker && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-sapling-cream z-[100] p-6 pt-12"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-3xl">Growth Tracker</h2>
              <button onClick={() => setShowTracker(false)} className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">✕</button>
            </div>
            <div className="space-y-6">
              <Card className="text-center py-12">
                <TreeDeciduous className="w-32 h-32 mx-auto text-sapling-green mb-4" />
                <p className="text-xl italic">"Every seed has its own time to bloom."</p>
              </Card>
              <div className="grid grid-cols-2 gap-4">
                <Button onClick={() => setShowTracker(false)}>Log Kindness</Button>
                <Button onClick={() => setShowTracker(false)}>Log Manners</Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Global Navigation (The Soil) */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-md border-t border-sapling-accent/20 px-6 py-4 flex justify-between items-center z-50">
        <NavButton 
          active={activeTab === 'home'} 
          onClick={() => setActiveTab('home')} 
          icon={<TreeDeciduous />} 
          label="The Garden" 
        />
        <NavButton 
          active={activeTab === 'calendar'} 
          onClick={() => setActiveTab('calendar')} 
          icon={<CalendarIcon />} 
          label="Seasons" 
        />
        <NavButton 
          active={activeTab === 'directory'} 
          onClick={() => setActiveTab('directory')} 
          icon={<Trees />} 
          label="The Forest" 
        />
        <NavButton 
          active={activeTab === 'communications'} 
          onClick={() => setActiveTab('communications')} 
          icon={<Wind />} 
          label="The Breeze" 
        />
      </nav>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 transition-all",
        active ? "text-sapling-green scale-110" : "text-sapling-green/40 hover:text-sapling-green/60"
      )}
    >
      {React.cloneElement(icon as React.ReactElement, { className: "w-6 h-6" })}
      <span className="text-[10px] font-bold uppercase tracking-tighter">{label}</span>
    </button>
  );
}
