export type BehaviorType = 'kindness' | 'manners' | 'sharing' | 'listening' | 'patience';

export interface BehaviorLog {
  id: string;
  type: BehaviorType;
  timestamp: number;
  note?: string;
}

export interface DevelopmentMilestone {
  id: string;
  category: 'cognitive' | 'social' | 'motor' | 'language';
  title: string;
  completed: boolean;
  dateCompleted?: number;
}

export interface Child {
  id: string;
  name: string;
  avatar: string;
  behaviorLogs: BehaviorLog[];
  milestones: DevelopmentMilestone[];
  classId?: string;
  attendanceStatus?: 'present' | 'absent' | 'late';
  checkInTime?: string;
}

export interface Activity {
  id: string;
  title: string;
  description: string;
  category: 'play' | 'learning' | 'creative';
  ageRange: string;
  icon: string;
}

export interface SchoolEvent {
  id: string;
  title: string;
  date: string;
  time?: string;
  type: 'event' | 'academic' | 'social';
}

export interface Teacher {
  id: string;
  name: string;
  role: string;
  avatar: string;
  email: string;
}

export interface SchoolClass {
  id: string;
  name: string;
  teachers: Teacher[];
  students: Child[];
}

export interface School {
  id: string;
  name: string;
  description: string;
  announcements: string[];
  classes: SchoolClass[];
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: number;
}
